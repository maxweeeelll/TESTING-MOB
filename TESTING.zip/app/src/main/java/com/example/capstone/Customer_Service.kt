package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.*

class Customer_Service : AppCompatActivity() {
    private lateinit var backButton: Button
    private lateinit var submitButton: Button
    private lateinit var serviceTypeGroup: RadioGroup

    // Personal Information
    private lateinit var fullNameInput: EditText
    private lateinit var emailInput: EditText
    private lateinit var contactInput: EditText

    // Address Information
    private lateinit var streetInput: EditText
    private lateinit var stateInput: EditText
    private lateinit var zipInput: EditText

    // Shipment Details
    private lateinit var itemsInput: EditText
    private lateinit var weightInput: EditText
    private lateinit var lengthInput: EditText
    private lateinit var widthInput: EditText
    private lateinit var heightInput: EditText

    // Pickup and Delivery
    private lateinit var pickupInput: EditText
    private lateinit var dropoffInput: EditText
    private lateinit var preferredDateInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.customer_service)

        initializeViews()
        setupClickListeners()
        setupDatePicker()
    }

    private fun initializeViews() {
        backButton = findViewById(R.id.backButton)
        submitButton = findViewById(R.id.submitButton)
        serviceTypeGroup = findViewById(R.id.serviceTypeGroup)

        fullNameInput = findViewById(R.id.fullNameInput)
        emailInput = findViewById(R.id.emailInput)
        contactInput = findViewById(R.id.contactInput)

        streetInput = findViewById(R.id.streetInput)
        stateInput = findViewById(R.id.stateInput)
        zipInput = findViewById(R.id.zipInput)

        itemsInput = findViewById(R.id.itemsInput)
        weightInput = findViewById(R.id.weightInput)
        lengthInput = findViewById(R.id.lengthInput)
        widthInput = findViewById(R.id.widthInput)
        heightInput = findViewById(R.id.heightInput)

        pickupInput = findViewById(R.id.pickupInput)
        dropoffInput = findViewById(R.id.dropoffInput)
        preferredDateInput = findViewById(R.id.preferredDateInput)
    }

    private fun setupClickListeners() {
        backButton.setOnClickListener {
            navigateToHomepage()
        }

        submitButton.setOnClickListener {
            if (validateInputs()) {
                submitBooking()
            }
        }
    }

    private fun setupDatePicker() {
        preferredDateInput.setOnClickListener {
            showDatePickerDialog()
        }
    }

    private fun showDatePickerDialog() {
        val calendar = Calendar.getInstance()
        val datePickerDialog = android.app.DatePickerDialog(
            this,
            { _, year, month, dayOfMonth ->
                val selectedDate = Calendar.getInstance()
                selectedDate.set(year, month, dayOfMonth)

                val dateFormat = SimpleDateFormat("MM/dd/yyyy", Locale.US)
                preferredDateInput.setText(dateFormat.format(selectedDate.time))
            },
            calendar.get(Calendar.YEAR),
            calendar.get(Calendar.MONTH),
            calendar.get(Calendar.DAY_OF_MONTH)
        )
        datePickerDialog.datePicker.minDate = System.currentTimeMillis() - 1000
        datePickerDialog.show()
    }

    private fun validateInputs(): Boolean {
        val inputs = listOf(
            Pair(serviceTypeGroup.checkedRadioButtonId != -1, "Please select a service type"),
            Pair(fullNameInput.text.toString().trim().isNotEmpty(), "Please enter your full name"),
            Pair(isValidEmail(emailInput.text.toString().trim()), "Please enter a valid email address"),
            Pair(isValidPhone(contactInput.text.toString().trim()), "Please enter a valid contact number"),
            Pair(streetInput.text.toString().trim().isNotEmpty(), "Please enter your street address"),
            Pair(stateInput.text.toString().trim().isNotEmpty(), "Please enter your state/region"),
            Pair(zipInput.text.toString().trim().isNotEmpty(), "Please enter your ZIP code"),
            Pair(itemsInput.text.toString().trim().isNotEmpty(), "Please specify the items"),
            Pair(isValidNumber(weightInput.text.toString().trim()), "Please enter a valid weight"),
            Pair(isValidNumber(lengthInput.text.toString().trim()), "Please enter a valid length"),
            Pair(isValidNumber(widthInput.text.toString().trim()), "Please enter a valid width"),
            Pair(isValidNumber(heightInput.text.toString().trim()), "Please enter a valid height"),
            Pair(pickupInput.text.toString().trim().isNotEmpty(), "Please enter pickup location"),
            Pair(dropoffInput.text.toString().trim().isNotEmpty(), "Please enter dropoff location"),
            Pair(preferredDateInput.text.toString().trim().isNotEmpty(), "Please select preferred date")
        )
        for ((isValid, errorMessage) in inputs) {
            if (!isValid) {
                Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
                return false
            }
        }
        return true
    }

    private fun isValidEmail(email: String) = android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()

    private fun isValidPhone(phone: String) = phone.length >= 10 && phone.all { it.isDigit() }

    private fun isValidNumber(number: String): Boolean {
        return try {
            number.toFloat() > 0
        } catch (e: NumberFormatException) {
            false
        }
    }

    private fun submitBooking() {
        val bookingDetails = Bundle().apply {
            putString("serviceType", if (serviceTypeGroup.checkedRadioButtonId == R.id.dedicatedDelivery) "Dedicated" else "Non-Dedicated")
            putString("fullName", fullNameInput.text.toString())
            putString("email", emailInput.text.toString())
            putString("contact", contactInput.text.toString())
            putString("street", streetInput.text.toString())
            putString("state", stateInput.text.toString())
            putString("zip", zipInput.text.toString())
            putString("items", itemsInput.text.toString())
            putString("weight", weightInput.text.toString())
            putString("dimensions", "${lengthInput.text}x${widthInput.text}x${heightInput.text}")
            putString("pickup", pickupInput.text.toString())
            putString("dropoff", dropoffInput.text.toString())
            putString("preferredDate", preferredDateInput.text.toString())
        }
        val intent = Intent(this, Fleet::class.java)
        intent.putExtras(bookingDetails)
        startActivity(intent)
        finish()
    }

    private fun navigateToHomepage() {
        startActivity(Intent(this, Homepage::class.java))
        finish()
    }
}
