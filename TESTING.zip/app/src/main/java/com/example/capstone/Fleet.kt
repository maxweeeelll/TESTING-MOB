package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

// Data class to represent truck details
data class Truck(
    val vehicleId: String,
    val vendor: String,
    val type: String,
    val color: String,
    val weightLimit: Double,
    val maxLength: Double,
    val maxWidth: Double,
    val maxHeight: Double,
    val driverName: String,
    val isAvailable: Boolean
)

class Fleet : AppCompatActivity() {
    private lateinit var trucksRecyclerView: RecyclerView
    private var selectedTruck: Truck? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fleet)

        // Initialize UI components
        trucksRecyclerView = findViewById(R.id.trucksRecyclerView)
        val backButton = findViewById<TextView>(R.id.button3)
        val saveChangesButton = findViewById<TextView>(R.id.saveChangesButton)

        // Display customer data passed through intent
        displayCustomerData()

        // Set up RecyclerView to display truck list
        setupTrucksList()

        // Back button functionality
        backButton.setOnClickListener {
            navigateToCustomerService()
        }

        // Save changes and navigate to truckingvendor with selected truck details
        saveChangesButton.setOnClickListener {
            navigateToTruckingVendor()
        }
    }

    // Display customer data received from intent
    private fun displayCustomerData() {
        intent.extras?.let { extras ->
            findViewById<TextView>(R.id.customerNameValue).text = extras.getString("fullName", "N/A")
            findViewById<TextView>(R.id.itemsValue).text = extras.getString("items", "N/A")
            findViewById<TextView>(R.id.pickupValue).text = extras.getString("pickup", "N/A")
            findViewById<TextView>(R.id.dropoffValue).text = extras.getString("dropoff", "N/A")
            findViewById<TextView>(R.id.dateTimeValue).text = extras.getString("preferredDate", "N/A")
        }
    }

    // Set up RecyclerView with truck list and click listeners
    private fun setupTrucksList() {
        val trucks = listOf(
            Truck("T001", "Vendor A", "10-Wheeler", "White", 15.0, 12.0, 2.5, 3.0, "Rodolfo", true),
            Truck("T002", "Vendor B", "6-Wheeler", "Black", 10.0, 8.0, 2.3, 2.8, "Tanggol ", true),
            Truck("T003", "Vendor C", "Wing Van", "Gray", 20.0, 15.0, 2.8, 3.5, "Mike Tyson", false)
        )
        val adapter = TruckAdapter(trucks) { truck ->
            selectedTruck = truck
            Toast.makeText(this, "Selected truck: ${truck.vehicleId}", Toast.LENGTH_SHORT).show()
        }
        trucksRecyclerView.layoutManager = LinearLayoutManager(this)
        trucksRecyclerView.adapter = adapter
    }

    // Navigate to Customer Service page
    private fun navigateToCustomerService() {
        startActivity(Intent(this, Customer_Service::class.java))
    }

    // Navigate to truckingvendor activity with selected truck and customer details
    private fun navigateToTruckingVendor() {
        if (selectedTruck != null) {
            val intent = Intent(this, truckingvendor::class.java).apply {
                // Pass truck details
                putExtra("vehicleId", selectedTruck?.vehicleId)
                putExtra("vendor", selectedTruck?.vendor)
                putExtra("type", selectedTruck?.type)
                putExtra("driverName", selectedTruck?.driverName)
                putExtra("isAvailable", selectedTruck?.isAvailable)

                // Pass customer details
                putExtra("customerName", findViewById<TextView>(R.id.customerNameValue).text.toString())
                putExtra("items", findViewById<TextView>(R.id.itemsValue).text.toString())
                putExtra("pickup", findViewById<TextView>(R.id.pickupValue).text.toString())
                putExtra("dropoff", findViewById<TextView>(R.id.dropoffValue).text.toString())
                putExtra("dateTime", findViewById<TextView>(R.id.dateTimeValue).text.toString())
            }
            Toast.makeText(this, "Truck selection saved!", Toast.LENGTH_SHORT).show()
            startActivity(intent)
        } else {
            Toast.makeText(this, "Please select a truck first", Toast.LENGTH_SHORT).show()
        }
    }

    // RecyclerView Adapter for displaying trucks
    inner class TruckAdapter(
        private val trucks: List<Truck>,
        private val onTruckSelected: (Truck) -> Unit
    ) : RecyclerView.Adapter<TruckAdapter.TruckViewHolder>() {

        inner class TruckViewHolder(view: View) : RecyclerView.ViewHolder(view) {
            val cardView: CardView = view.findViewById(R.id.truckCard)
            val vehicleId: TextView = view.findViewById(R.id.vehicleId)
            val vendor: TextView = view.findViewById(R.id.vendor)
            val type: TextView = view.findViewById(R.id.type)
            val details: TextView = view.findViewById(R.id.details)
            val driver: TextView = view.findViewById(R.id.driver)
            val availabilityStatus: TextView = view.findViewById(R.id.availabilityStatus)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TruckViewHolder {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.truck_item, parent, false)
            return TruckViewHolder(view)
        }

        override fun onBindViewHolder(holder: TruckViewHolder, position: Int) {
            val truck = trucks[position]
            holder.vehicleId.text = "Vehicle ID: ${truck.vehicleId}"
            holder.vendor.text = "Vendor: ${truck.vendor}"
            holder.type.text = "Type: ${truck.type}"
            holder.details.text = "Specifications:\n" +
                    "Weight Limit: ${truck.weightLimit}t\n" +
                    "Max Dimensions: ${truck.maxLength}L x ${truck.maxWidth}W x ${truck.maxHeight}H"
            holder.driver.text = "Driver: ${truck.driverName}"
            holder.availabilityStatus.text = if (truck.isAvailable) "Available" else "Not Available"
            holder.availabilityStatus.setTextColor(
                if (truck.isAvailable) holder.itemView.context.getColor(android.R.color.holo_green_dark)
                else holder.itemView.context.getColor(android.R.color.holo_red_dark)
            )

            holder.cardView.setOnClickListener {
                if (truck.isAvailable) {
                    onTruckSelected(truck)
                } else {
                    Toast.makeText(
                        holder.itemView.context,
                        "This truck is currently not available",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }

        override fun getItemCount() = trucks.size
    }
}
