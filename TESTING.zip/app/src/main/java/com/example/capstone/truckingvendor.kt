package com.example.capstone

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import android.view.animation.AnimationUtils

class truckingvendor : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_truckingvendor)

        // Apply window insets
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Apply animations
        setupAnimations()

        // Process intent extras
        processIntentExtras()

        // Setup UI components
        setupStatusSpinner()
        setupNavigationButtons()
    }

    private fun setupAnimations() {
        // Load animations
        val fadeIn = AnimationUtils.loadAnimation(this, android.R.anim.fade_in)

        // Find views to animate
        val contentLayout = findViewById<LinearLayout>(R.id.contentLayout)
        val buttonsLayout = findViewById<LinearLayout>(R.id.buttonsLayout)

        // Apply animations
        contentLayout.startAnimation(fadeIn)
        buttonsLayout.startAnimation(fadeIn)
    }

    private fun processIntentExtras() {
        intent.extras?.let { extras ->
            // Update truck details
            updateTruckDetails(
                vehicleId = extras.getString("vehicleId", "N/A"),
                vendor = extras.getString("vendor", "N/A"),
                type = extras.getString("type", "N/A"),
                driver = extras.getString("driverName", "N/A"),
                availability = extras.getBoolean("isAvailable")
            )

            // Update customer details
            updateCustomerDetails(
                fullName = extras.getString("customerName", "N/A"),
                items = extras.getString("items", "N/A"),
                pickup = extras.getString("pickup", "N/A"),
                dropoff = extras.getString("dropoff", "N/A"),
                preferredDate = extras.getString("dateTime", "N/A")
            )
        }
    }

    private fun updateTruckDetails(vehicleId: String, vendor: String, type: String,
                                   driver: String, availability: Boolean) {
        findViewById<TextView>(R.id.truck_info).text = " $type ($vehicleId)"
        findViewById<TextView>(R.id.route_info).text = "$vendor"
        findViewById<TextView>(R.id.driver_info).text = "$driver"

        val availabilityText = if (availability) "Available" else "Not Available"
        val availabilityColor = if (availability)
            getColor(R.color.status_available)
        else getColor(R.color.status_unavailable)

        findViewById<TextView>(R.id.availability_status).apply {
            text = availabilityText
            setTextColor(availabilityColor)
        }
    }

    private fun updateCustomerDetails(fullName: String, items: String, pickup: String,
                                      dropoff: String, preferredDate: String) {
        findViewById<TextView>(R.id.customerNameValue).text = fullName
        findViewById<TextView>(R.id.itemsValue).text = items
        findViewById<TextView>(R.id.pickupValue).text = pickup
        findViewById<TextView>(R.id.dropoffValue).text = dropoff
        findViewById<TextView>(R.id.dateTimeValue).text = preferredDate
    }

    private fun setupStatusSpinner() {
        findViewById<Spinner>(R.id.statusSpinner).apply {
            setSelection(0)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?,
                                            position: Int, id: Long) {
                    val status = parent?.getItemAtPosition(position).toString()
                    showStatusUpdateToast(status)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
        }
    }

    private fun showStatusUpdateToast(status: String) {
        Toast.makeText(this, "Status updated to: $status", Toast.LENGTH_SHORT).show()
    }

    private fun setupNavigationButtons() {
        // View Return Policy button
        findViewById<Button>(R.id.returnPolicyButton).setOnClickListener {
            // Open the ReturnPolicyActivity
            val intent = Intent(this, ReturnPolicyActivity::class.java)
            startActivity(intent)
        }

        // Heatmap button
        findViewById<Button>(R.id.heatmapButton).setOnClickListener {
            // Open the HeatmapActivity
            val intent = Intent(this, heatmap::class.java)
            startActivity(intent)
        }

        // Back button
        findViewById<Button>(R.id.backButton).setOnClickListener {
            navigateToFleet()
        }
    }

    private fun navigateToFleet() {
        startActivity(Intent(this, Fleet::class.java))
        finish()
    }

    override fun onBackPressed() {
        navigateToFleet()
    }
}

